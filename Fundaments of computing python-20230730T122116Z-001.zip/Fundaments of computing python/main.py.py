import rent
import return_1
def main():
    chck = True
    while chck == True:
        print("Select a desirable Option \n(1)  1 to rent a costume\n(2)  2 to return a costume\n(3)  3  to exit.\n")
        try:
            user = int(input("Enter an option: "))
           
            if user == 1:
                print("\n\nLet's rent a costume\n\n")
                rent.rent()
                
            elif user == 2:
                print("lets return costume")
                return_1.rtrn()
            
            elif user == 3:
                chck=False
                
                
            else:
                print("\n\nInvalid input!!!!!\n\n")
        except:
            print("Invalid input")

main()
