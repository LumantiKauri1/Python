from datetime import datetime
cart = []                              
cart_dict ={}                             
name = input("Enter full name: ")     
id = input("Enter CitizenShip number: ") 

def read_cart():
    stock = open('costumes.txt','r')               
    stock_list = stock.readlines()             
    Dict = {}                          

    for i in range(1,len(stock_list) + 1): 
        Dict[i] = stock_list[i-1].split(",")     
    
    for i in range(1, len(Dict) + 1):  
        Dict[i].pop(4)                 

    return Dict



    



# date and time
year = str(datetime.now().year)
month = str(datetime.now().month)
day = str(datetime.now().day)
hour = str(datetime.now().hour)
minutes = str(datetime.now().minute)
date_today = year + " - " + month + " - " + day + " , " + hour + " : " + minutes 



while True: 
    try:
        days = int(input("Enter the number of days you want to rent the costume for: "))
        break
    except:
        print("Enter valid data")


D = read_cart()
def rent():

    try:
        
        print("--------------------------------------------------------------------------------------------------")
        print("  ID\t\tCostume\t\tBrand\t\tPrice\t\tQuantity") 
        print("--------------------------------------------------------------------------------------------------\n")
    
        for i in range(1, len(D)+1):
            print("  {0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\n".format(i, D[i][0],D[i][1],D[i][2],D[i][3])) 
        print("--------------------------------------------------------------------------------------------------")

        choose = int(input("Enter the ID of the costume you want to rent: "))    
        present = False 

        for i in range(1, len(D) + 1):       
            if choose == i:
                present = True      
                break
    
        if present == False: 
            print("\n\n")
            print("--------------------------------------")
            print("Please Enter a valid ID !!! ")
            print("--------------------------------------\n\n")
            rent()
        else:
         
            if int(D[choose][3]) == 0:
                print("\n\n")
                print("--------------------------------------")
                print("Costume out of stock !!! ")
                print("--------------------------------------\n\n")
                rent()
            else: 
                print("Costume ID is {0}\n\n".format(choose))
                print("---------------------")    
                print("Costume is available")
                print("---------------------\n\n")

                choose_req = int(input("Enter the Quantity of the costume: ")) 

                if int(D[choose][3]) < choose_req:     
                    print("----------------------------------------------------------")
                    print("Quantity provided is greater than what we have in stock!!!")     
                    print("----------------------------------------------------------")
                    print(D, "\n\n")
                    rent()
                else:

                    # remove $ from the price
                    count = 0
                    price = "" 

                    for i in D[choose][2]:
                        if count > 0: 
                            price = price + i 
                        count = count + 1
                    
                    
                    act_pr = "{:.2f}".format((int(price)/5) *choose_req * days) 
           

                    cart.append([choose,D[choose][0], D[choose][1], str(choose_req), D[choose][2], act_pr ]) 
                    for i in range(1,len(cart)+1):
                        cart_D[i] = cart[i-1]

                    print("Your cart:\n {0}".format(cart_D))


                    D[choose][3]= str(int(D[choose][3]) - choose_req)     

                    recheck_validation = False 

                    while recheck_validation == False:
                        recheck = input("Do you want to rent any thing else? (Y/N): ")
                        if recheck.upper() == "Y": 
                            rent()
                            recheck_validation = True
                        elif recheck.upper() == "N": 
                            recheck_validation = True
                            bill(name, id, days, date_today, cart_D) 
                            print(D)        
                            update_stock(D) 
                            invoice(name, id, days, date_today, cart_D) 
                            cart_(name, id, cart_D, date_today) 
                            clear_() 
                            
                        else:
                            print("-----------------------")
                            print("  Enter either Y or N  ")
                            print("-----------------------")
    except:
        print("--------------------------")
        print("  Invalid input  ")
        print("--------------------------")
    
        


def bill(name, id, days, date_today, cart_D):  
    print("Your bill:\n")
    print("---------------------------------------------------------------------------------------------------")
    print("  Name: "+name+"\t\t" + "ID: "+id +"\t\t"+ "For: "+ str(days) + " Day/s" +"\n  "+ date_today)
    print("----------------------------------------------------------------------------------------------------")
    print("  Sno.\tCostume ID\t\t Name\t\tBrand\t\tQuantity\trate\tTotal  ")
    print("---------------------------------------------------------------------------------------------------")
    for i in range(1, len(cart_D) + 1): 
        print("  {0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t{6}  ".format(i,cart_D[i][0], cart_D[i][1], cart_D[i][2], cart_D[i][3],cart_D[i][4], "$" + str(cart_D[i][5])  )) # i-1 because i starts form 1 and list index starts from 0
    print("---------------------------------------------------------------------------------------------------")
    total_amount = float(0) 
    for i in range(1, len(cart_D)+1):
        total_amount = total_amount + float(cart_D[i][5])
                    
    print("Total Amount:","$" + str("{:.2f}".format(total_amount)))
    print("---------------------------------------------------------------------------------------------------")


def update_stock(D):
    stock2 = open('costumes.txt','w')    
    for i in range(1, len(D)+1):
        for j in range(4):          
            stock2.write(D[i][j])           
            stock2.write(',')           
        stock2.write("\n")      
    stock2.close()
    

def invoice(name, id, days, date_today, cart_D):
    invoice = open(name.upper()+" "+id+" rented"+".txt","w")
    invoice.write("Your bill:\n")
    invoice.write("-----------------------------------------------------------------------------------------------------------------------")
    invoice.write("\n")
    invoice.write("  Name: "+name+"\t\t" + "ID: "+id +"\t\t"+ "For: "+ str(days) + " Day/s" +"\n  "+ date_today)
    invoice.write("\n")
    invoice.write("-----------------------------------------------------------------------------------------------------------------------")
    invoice.write("\n")
    invoice.write("  Sno.\t\tCostume ID\t\tCostume Name\t\tBrand\t\tQuantity\trate\t\tTotal  ")
    invoice.write("\n")
    invoice.write("-----------------------------------------------------------------------------------------------------------------------")
    invoice.write("\n")
    for i in range(1, len(cart_D) + 1): # i+1 becaust Sno starts form 1
        invoice.write("  {0}\t\t{1}\t\t\t{2}\t\t{3}\t{4}\t\t{5}\t\t{6}  ".format(i,cart_D[i][0], cart_D[i][1], cart_D[i][2], cart_D[i][3],cart_D[i][4], "$" + str(cart_D[i][5])  )) # i-1 because i starts form 1 and list index starts from 0
        invoice.write("\n")
    invoice.write("-----------------------------------------------------------------------------------------------------------------------")
    invoice.write("\n")
    total_amount = float(0) # local variable to store total amount
    for i in range(1, len(cart_D)+1): # adds the prices in the cart and stores in total_amount
        total_amount = total_amount + float(cart_D[i][5])
                    
    invoice.write("Total Amount: "+"$" + str("{:.2f}".format(total_amount)))# total as float with 2 digits after decimal
    invoice.write("\n")
    invoice.write("-----------------------------------------------------------------------------------------------------------------------")
    invoice.close()



def cart_(name, id, cart_D, date_today):
    cart_p = open(name.upper()+" "+id+" rent cart"+".txt",'w')      
    for i in range(1, len(cart_D)+1):            
        for j in range(6):        
            cart_p.write(str(cart_D[i][j]))
            cart_p.write(',')           
        cart_p.write("\n")     
    cart_p.write(date_today)
    cart_p.write("\n")
    cart_p.close()
    return cart_p




def clear_():
    is_empty = False
    while is_empty == False:
        try:
            cart.pop() 
            cart_D.popitem() 
        except:
            is_empty = True 
    
    return is_empty
    

